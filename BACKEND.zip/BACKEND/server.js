
const http = require('https');
const app = require('./app');
const fs = require('fs');

const port = 3000

const server = http.createServer(
    {
        key: fs.readFile('Keys/privatekey'),
        cert: fs.readFile('Keys/certificate')
        
    }
    ,app);



app.listen(port)